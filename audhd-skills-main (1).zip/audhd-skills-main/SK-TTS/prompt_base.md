# SK-TTS: Text-to-Speech Output Routing (v2)

## Purpose
Post-execute hook that adapts text output for speech synthesis based on cognitive state, energy level, content type, and audience.

## Cognitive Rationale
AuDHD users processing audio output have different capacity constraints than when reading. Spoken output that's too dense, too fast, or structurally complex (nested lists, tables, code blocks) fails as audio. SK-TTS transforms structured text output into speech-optimized format with content-aware adaptation.

## Hook Lifecycle
- **Phase**: `post_execute` (prompt injection to shape output for speech)
- **Priority**: 90
- **Runs after**: All prompt-injection hooks, model execution, validation
- **Input**: Final model output text + cognitive state
- **Output**: Speech-optimized directives + SSML hints + voice parameters + duration estimate

## Processing Pipeline

### 1. Content Type Detection
Automatically detects content types in the output:
- **code**: Code blocks, inline code, imports, function/class definitions
- **table**: Markdown tables, HTML tables
- **list**: Bulleted or numbered lists
- **verdict**: Bold status markers (FIXED, CRITICAL, PASS, FAIL, etc.)
- **claim_tagged**: Content with [OBS], [DRV], [GEN], [SPEC] tags
- **narrative**: Default when no structured content detected

### 2. Content-Specific Speech Directives

**Code blocks:**
- Describe purpose in plain language, do NOT read syntax character by character
- Short snippets (<3 lines): read key identifiers and logic flow
- Long blocks: summarize structure and key logic only
- Variable names: spell out or use natural pronunciation

**Tables:**
- Convert to ranked comparisons or sequential descriptions
- Pattern: "The first option is [X], which has [property]. The second..."
- Large tables (4+ rows): summarize top 3, mention total count

**Lists:**
- Energy-gated max items (high=unlimited, medium=10, low=3, crash=1)
- Nested lists: flatten with depth cues ("Under the first point...")
- Number items when order matters

**Verdicts:**
- Lead with verdict, emphasize status
- Brief pause after verdict before supporting detail

**Claim tags vocalized:**
- [OBS] -> "This is observed:"
- [DRV] -> "This is inferred:"
- [SPEC] -> "This is unverified:"
- [GEN] -> (omit tag, treat as default)

### 3. SSML Hint Generation
Produces structured SSML hints for downstream TTS engine adapters:
```json
{
  "prosody": { "rate": "95%", "volume": "80%", "pitch": "-0.5st" },
  "breaks": [
    { "before": "Next Section", "strength": "strong", "duration_ms": 550 }
  ],
  "emphasis": [
    { "text": "CRITICAL", "level": "strong" }
  ],
  "say_as": [
    { "text": "API", "interpret_as": "characters", "pronunciation": "A P I" }
  ]
}
```

### 4. Pronunciation Guide
Built-in pronunciation hints for common technical terms:
- API, SQL, JSON, CLI, GUI, URL, HTTP, SSH, GPU, CPU
- npm, PyPI, pytest, kubectl, nginx, FastAPI, Pydantic
- AuDHD, ADHD, OSINT, SSML
- Extensible via `tts_custom_pronunciation` option

### 5. Duration Estimation
- Base: 150 words/minute adjusted by rate parameter
- Additive pauses: sentences (0.3s), headers (0.8s), paragraph breaks (1.0s)
- All pauses scaled by `pause_multiplier`
- Result stored as `tts_estimated_duration_sec`

### 6. Energy-Adaptive Voice Parameters
| Energy | Rate | Volume | Pause | Pitch | Max Sentences |
|---|---|---|---|---|---|
| high | 1.0x | 80% | 1.0x | +0.0st | unlimited |
| medium | 0.95x | 80% | 1.1x | -0.5st | 20 |
| low | 0.85x | 70% | 1.25x | -1.0st | 5 |
| crash | 0.75x | 60% | 1.5x | -1.5st | 1 |

## Model Routing
[OBS — G-FLA31 is not a registered alias in adapters/config.yaml. Using registered aliases only.]
- **Primary**: O-O4M (o4-mini — registered T1 rapid verifier, lowest cost)
- **Fallback**: O-53 (gpt-5.3 — registered T2 overflow)
- **Never**: T4+ models for post-processing text transformation
- **Note**: Register G-FLA alias → gemini-2.5-flash-lite in config.yaml if Gemini TTS prep is preferred
- TTS inference itself is external (Google Cloud TTS, Azure, ElevenLabs)
- This skill prepares text, parameters, and SSML hints only

## Options Output
```json
{
  "tts_voice_params": { "rate": 0.95, "volume": 0.8, "pause_multiplier": 1.1, "pitch_semitones": -0.5 },
  "tts_content_types": ["table", "verdict", "claim_tagged"],
  "tts_estimated_duration_sec": 45.2,
  "tts_ssml_hints": { ... },
  "tts_max_sentences": 20
}
```
