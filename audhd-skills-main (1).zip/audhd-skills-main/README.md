# audhd-skills

Skill definitions and cognitive augmentation layer for the [AuDHD Cognitive Swarm Protocol](https://github.com/AICincy/audhd-agents).

This repo contains prompt templates, schemas, and meta-skill definitions. The runtime that executes them lives in [audhd-agents](https://github.com/AICincy/audhd-agents).

MIT License — [AICincy](https://github.com/AICincy)

## What's here

```
_base/                  Cognitive augmentation base layer
  prompt_base.md        Preamble injected before every skill execution
  schema_base.json      Shared cognitive_state JSON Schema
  PROFILE.md            Condensed AuDHD cognitive reference
  skills/               Always-on hook definitions
    reality_check.json  Claim tagging and output gating
    energy_routing.json Energy-adaptive model selection
    externalization.json State externalization rules
  reality_adapter_template.json  Reality-check adapter template

SK-SCHOLAR/             Context monitoring: energy signals, drift, overload detection
SK-STT/                 Speech-to-text with AuDHD-aware transcript cleanup
SK-TONE/                Tone analysis and register adaptation
SK-TTS/                 Text-to-speech with SSML and prosody control

skills/                 Domain skill prompt templates (VoltAgent format)
  data-ai/              llm-architect
  infrastructure/       deployment-engineer, devops-engineer, docker-expert, sre-engineer
  meta-orchestration/   context-manager, multi-agent-coordinator
  quality-security/     security-auditor
```

## Base layer

`_base/` is injected before every skill execution by the hooks pipeline. Do not modify without updating `runtime/validation.py` in audhd-agents.

| File | Purpose |
|------|---------|
| `prompt_base.md` | Cognitive augmentation preamble: energy routing, output rules, claim tagging, provider routing table |
| `schema_base.json` | Shared `cognitive_state` JSON Schema aligned with `runtime/schemas.py` |
| `PROFILE.md` | Condensed AuDHD cognitive reference (full spec in [audhd-agents/PROFILE.md](https://github.com/AICincy/audhd-agents/blob/main/PROFILE.md)) |

### Always-on hook definitions

Three hooks fire on every execution regardless of skill configuration:

| File | Hook | What it does |
|------|------|-------------|
| `_base/skills/reality_check.json` | reality-check | Tags claims `[observed/inferred/general/unverified]`, gates T3+ output |
| `_base/skills/energy_routing.json` | energy-route | Routes to model tier based on energy level |
| `_base/skills/externalization.json` | externalization | Enforces state externalization rules |

## Meta-skills

Specialized skills with their own prompt and schema, consumed by `hooks_scholar.py` and the speech/tone pipeline in audhd-agents.

| Skill | Directory | What it does |
|-------|-----------|-------------|
| SK-SCHOLAR | `SK-SCHOLAR/` | Context monitoring: energy signals, drift detection, overload detection |
| SK-STT | `SK-STT/` | Speech-to-text with AuDHD-aware transcript cleanup |
| SK-TONE | `SK-TONE/` | Tone analysis and register adaptation |
| SK-TTS | `SK-TTS/` | Text-to-speech with SSML and prosody control |

Each contains `prompt_base.md` (prompt logic) and `schema_base.json` (validation schema).

## Domain skills

8 prompt templates across 4 categories. Loaded by `build.py` in audhd-agents. Each is a Markdown prompt file — no runtime code. The cognitive augmentation layer from `_base/prompt_base.md` is injected at runtime.

| Category | Skills |
|----------|--------|
| data-ai | llm-architect |
| infrastructure | deployment-engineer, devops-engineer, docker-expert, sre-engineer |
| meta-orchestration | context-manager, multi-agent-coordinator |
| quality-security | security-auditor |

## Cognitive state schema

All skills share a single `cognitive_state` contract defined in `_base/schema_base.json`.

Required fields:

| Field | Type | Values |
|-------|------|--------|
| `energy_level` | string | `high`, `medium`, `low`, `crash` |
| `attention_state` | string | `focused`, `diffuse`, `transitioning` |

Optional: `active_mode`, `task_tier`, `active_thread`, `context_switches`, `session_context`, `request_id`, `resume_from`, `resume_context`, `skill_input`, `skill_output`.

## Claim tagging

All T3+ outputs must tag claims. Enforced by `runtime/validation.py` in audhd-agents.

| Tag | Meaning |
|-----|---------|
| `[observed]` | Directly retrieved from workspace, tool, or document |
| `[inferred]` | Logically derived from observed facts |
| `[general]` | Widely known background knowledge |
| `[unverified]` | Plausible but not confirmed |

## Grounding policy

Every skill must be grounded — it describes what the runtime code actually does, not aspirational features. See [GROUNDING.md](GROUNDING.md) for the full registry and design constraints.

Key constraints:
- Skills are tools the operator uses, not interventions imposed
- Prompt-injection is the execution model — no persistent listeners, no inter-skill message bus
- Crash mode reduces load; it does not block agency
- Silent autonomous action is explicitly excluded

## Setup

This repo is consumed by [audhd-agents](https://github.com/AICincy/audhd-agents) at runtime. To use skills:

```bash
git clone https://github.com/AICincy/audhd-skills
```

Full runtime setup (providers, API keys, testing) is in [audhd-agents/README.md](https://github.com/AICincy/audhd-agents/blob/main/README.md).

## Related

- [AICincy/audhd-agents](https://github.com/AICincy/audhd-agents) — runtime, router, hooks pipeline, FastAPI service, CLI
- [GROUNDING.md](GROUNDING.md) — what every component actually does vs. aspirational
- [PROFILE.md](https://github.com/AICincy/audhd-agents/blob/main/PROFILE.md) — full cognitive profile and output constraints
- [AGENT.md](https://github.com/AICincy/audhd-agents/blob/main/AGENT.md) — routing matrix, circuit breakers, cost tracking

## Source

Domain skill prompts adapted from [VoltAgent/awesome-claude-code-subagents](https://github.com/VoltAgent/awesome-claude-code-subagents) for Gemini + OpenAI providers. The cognitive augmentation layer (`_base/`, `SK-*`) is original.

## Contributing

Contributions welcome, especially from neurodivergent developers.

[Open an issue](https://github.com/AICincy/audhd-skills/issues) for bugs, skill requests, or cognitive profile adaptations.
