# Skill Grounding Registry

Every skill must be grounded: it describes what the runtime code ACTUALLY DOES, not aspirational features.

## Design Constraints (from audit discussion)

1. **Augmentation for competent adults.** Not caretaker. Not safety scaffolding.
2. **Autonomous agentic.** Skills communicate with skills, LLMs with LLMs. Operator sets intent, swarm executes.
3. **Cognitive offloading at scale.** One intent, parallel decomposition, merged deliverable. "Million tasks, one hand."
4. **Prompt-injection is what works NOW.** No independent action. No persistent listener. No inter-skill message bus.
5. **Crash mode reduces load.** Does not block agency.
6. **Skills are tools the operator uses.** Not interventions imposed.

## Grounding Status

| Skill | Type | Phase | Always-On | Runtime (hooks.py) | Definition (audhd-skills) | Grounded |
|-------|------|-------|-----------|--------------------|--------------------------|---------|
| decompose | Cognitive | pre_execute | No | ✅ Python | ✅ | ✅ |
| bridge | Cognitive | pre_execute | No | ✅ Python (v2: structured context) | ✅ | ✅ |
| quality-gate | Cognitive | prompt_injection | No | ✅ Python | ✅ | ✅ |
| verify | Cognitive | prompt_injection | No | ✅ Python | ✅ | ✅ |
| focus | Cognitive | prompt_injection | No | ✅ Python | ✅ | ✅ |
| format | Cognitive | prompt_injection | No | ✅ Python | ✅ | ✅ |
| reality-check | Cognitive | prompt_injection | **Yes** | ✅ Python | ✅ JSON + prompt | ✅ |
| energy-route | Cognitive | prompt_injection | **Yes** | ✅ Python (+P2.5 context monitoring) | ✅ JSON | ✅ |
| knowledge-inject | Cognitive | prompt_injection | **Yes** | ✅ Python (hooks_scholar.py) | ✅ | ✅ |
| load-skill | Cognitive | prompt_injection | No | ✅ Python | ✅ JSON | ✅ |
| resume | Cognitive | on_resume | No | ✅ Python | ✅ | ✅ |
| micro-step | Cognitive | prompt_injection | No | ✅ Python | ✅ | ✅ |
| anchor | Cognitive | prompt_injection | No | ✅ Python (v2: topic stack, decay) | ✅ | ✅ |
| code-review | Cognitive | prompt_injection | No | ✅ Python | ✅ | ✅ |
| refocus | Cognitive | prompt_injection | No | ✅ Python | ✅ | ✅ |
| accessibility | Cognitive | prompt_injection | No | ✅ Python | ✅ | ✅ |
| system-audit | Cognitive | prompt_injection | No | ✅ Python | ✅ | ✅ |
| recover | Cognitive | on_error | No | ✅ Python | ✅ | ✅ |
| speech-input | I/O | pre_execute | No | ✅ Python (v2: 8-stage pipeline) | ✅ prompt+schema | ✅ |
| speech-output | I/O | post_execute | No | ✅ Python (v2: SSML+content detect) | ✅ prompt+schema | ✅ |
| tone | Style | prompt_injection | No | ✅ Python (v2: compound+valence) | ✅ prompt+schema | ✅ |

## Context Monitoring (P2.5)

**Status**: GROUNDED. Implemented in `runtime/hooks_scholar.py`.

| Monitor | Function | What It Does | What It Does NOT Do |
|---------|----------|-------------|---------------------|
| Energy signals | `detect_energy_signals()` | Regex/arithmetic on input text: frustration, fatigue, hyperfocus, urgency, scattered | ML inference, sentiment analysis, biometric data |
| Drift detection | `detect_drift_signals()` | Keyword overlap between input and active_thread | Semantic similarity, embedding comparison |
| Overload detection | `detect_overload_signals()` | Structural analysis: multi-request count, pronoun density, unstructured streams | Context window analysis, memory profiling |

Context monitors run on input text BEFORE hook execution. Results injected into `options` dict for downstream hooks (especially knowledge-inject and energy-route).

## knowledge-inject (P2.7)

**Status**: GROUNDED. Implemented in `runtime/hooks_scholar.py`.

**What it does**: Pre-execute knowledge-injection hook. Reads PROFILE.md cognitive model and injects AuDHD-grounded context into every skill's prompt based on current mode and energy.

**What it does NOT do**: Supervisor pattern (no inter-skill bus), persistent state (request-scoped only), independent action (prompt-injection only).

## NOT Feasible (Excluded)

These were discussed and explicitly excluded from implementation:

| Feature | Why Not |
|---------|--------|
| Supervisor pattern | No inter-skill message bus. Orchestrator handles routing. |
| Independent skill action | No persistent listener. Prompt-injection only. |
| Streaming context monitor | Architecture is request-scoped, not streaming. |
| Silent autonomous action | Violates augmentation-not-caretaker constraint. |
| Audit log for silent activations | Deferred to future milestone (needs persistent state). |

## Domain Skills (VoltAgent format)

These are prompt templates for domain-specific tasks, NOT runtime hooks:

| Skill | Category | Grounded |
|-------|----------|----------|
| llm-architect | data-ai | ✅ Prompt template. No runtime code needed. |
| deployment-engineer | infrastructure | ✅ Prompt template. |
| devops-engineer | infrastructure | ✅ Prompt template. |
| docker-expert | infrastructure | ✅ Prompt template. |
| sre-engineer | infrastructure | ✅ Prompt template. |
| context-manager | meta-orchestration | ✅ Prompt template. |
| multi-agent-coordinator | meta-orchestration | ✅ Prompt template. |
| security-auditor | quality-security | ✅ Prompt template. |

Domain skills are loaded by `build.py` via the VoltAgent importer (F3 fix). They receive the cognitive augmentation layer from `prompt_base.md` + active hooks at runtime.

---

## Infrastructure (audhd-agents)

Non-cognitive files. Not hooks. Grounded here for completeness per operator request.

"Hooks pipeline" = does the file invoke `run_hooks()` or `validate_output()` for LLM output? "No" is expected for framework and tooling files — hooks run inside `router.execute()`, which all execution paths call.

### Adapter Layer

| File | What It Does | Hooks Pipeline |
|------|-------------|---------------|
| `adapters/router.py` | `SkillRouter`: loads skills, resolves model chain per cognitive state, calls `run_hooks()` unconditionally (always-on included), calls provider adapter, calls `validate_output()`. Central execution hub. | **Yes — is the pipeline** |
| `adapters/base.py` | Abstract `LLMAdapter` base class. `SkillRequest`, `SkillResponse`, `CostRecord` dataclasses. No business logic. | No |
| `adapters/openai_adapter.py` | OpenAI provider: builds API call, returns `SkillResponse`. No hook or validation logic. | No |
| `adapters/google_adapter.py` | Gemini provider: rate limiting, token counting, cost tracking, API call. No hook or validation logic. | No |

### Runtime Framework

| File | What It Does | Hooks Pipeline |
|------|-------------|---------------|
| `runtime/app.py` | FastAPI app. Endpoints: `/healthz`, `/readyz`, `/execute`, `/webhooks/notion`. `/execute` calls `router.execute()` or `router.execute_chain()`. | Via router |
| `runtime/cognitive.py` | `parse_cognitive_state()`, `infer_mode()`, `filter_model_chain()`, `build_cognitive_preamble()`. Reads energy/mode/tier from request, filters model pool. | No (pre-execution) |
| `runtime/validation.py` | `validate_output()`: checks PROFILE.md contracts post-execution. Flags em dashes, filler, missing claim tags, motivation phrases. F9: skips CLAIM_TAGS for JSON responses. | Is the validator |
| `runtime/hooks.py` | `HOOK_REGISTRY` (20 hooks) + `ALWAYS_ON_HOOKS` (`reality-check`, `energy-route`). `run_hooks()`: prepends always-on, executes chain, merges results. | Is the hook runner |
| `runtime/hooks_scholar.py` | `knowledge-inject` hook (P2.7) + context monitors (P2.5): energy signal, drift, overload detection via text heuristics. Patches `HOOK_REGISTRY` and `ALWAYS_ON_HOOKS` at import. | Extends hook runner |
| `runtime/init_hooks.py` | Imports `hooks_scholar` to trigger its `HOOK_REGISTRY` patches at app startup. Re-exports for `app.py`. | No |
| `runtime/schemas.py` | Canonical `CognitiveState` dataclass, `EnergyLevel` enum, `ExecuteRequest`, `ExecuteResponse`, `CrashStateResponse`. Single source of truth for request/response shapes. | No |
| `runtime/pipeline_bridge.py` | Maps Notion webhook events to skill IDs. Builds `cognitive_state` and `input_text` from event payload. Calls `router.execute()`. | Via router |
| `runtime/webhooks.py` | Notion webhook endpoint. `EventRouter` with category-based handlers. LRU deduplicator. Handlers call `pipeline_bridge.dispatch_event()`. | Via pipeline_bridge → router |
| `runtime/webhook_schemas.py` | `WebhookEvent`, `EventCategory`, `WebhookEventType`, `ProcessedEvent` schemas for Notion events. | No |
| `runtime/sanitize.py` | Input sanitization: strips prompt-injection prefixes, detects suspicious patterns, normalizes whitespace. Runs before hook/model pipeline. | No (pre-pipeline) |
| `runtime/auth.py` | Bearer token auth for `/execute`. HMAC-SHA256 signature verification for webhook payloads. | No |
| `runtime/middleware.py` | ASGI middleware: request ID injection, CORS, structured logging, timing headers. | No |
| `runtime/config.py` | `RuntimeSettings` dataclass. Reads `APP_ENV`, `REQUIRED_PROVIDERS`, `LOG_LEVEL` from environment. | No |
| `runtime/planner.py` | `RuntimePlanner`: maps capability chain from skill graph to ordered skill ID list for `execute_chain()`. | No |
| `runtime/notion_client.py` | Notion API client: webhook subscription management, HMAC verification, paginated queries. No LLM calls. | No |

### Build System

| File | What It Does | Hooks Pipeline |
|------|-------------|---------------|
| `build.py` | Build-time manifest generator. Reads `skill.yaml`, `prompt.md`, `schema.json`, `examples.json`. Resolves `allOf/$ref` schemas. Outputs to `dist/`. No LLM calls, no hooks. | No (build-time only) |

### CLI

| File | What It Does | Hooks Pipeline |
|------|-------------|---------------|
| `cli/sk.py` | `sk` CLI: loads skill, builds prompt + cognitive header, calls `call_llm()`, calls `validate_output()` on response (mirrors router Step 8). Prints violations to stderr. | validate_output() only — no hooks |
| `cli/llm_client.py` | Multi-provider LLM client. Routes model aliases (G-PRO, O-54P, etc.) to provider calls. No hooks or validation. | No |
| `cli/skill_loader.py` | Discovers and loads skills from `skills/` directory. Reads `skill.yaml`, `prompt.md`, `schema.json`, `examples.json`. | No |
| `cli/validator.py` | JSON Schema input validation for skill payloads using `jsonschema`. | No |

### Scripts

| File | What It Does | Hooks Pipeline |
|------|-------------|---------------|
| `scripts/check_connections.py` | Checks provider API credentials and live connectivity. Config mode (no calls) + live mode (test calls). | No |
| `scripts/smoke_runtime.py` | Smoke tests for running runtime: checks `/healthz`, `/readyz`, `/webhooks/notion`. | No |
| `scripts/parallel_audit.py` | Runs parallel codebase analysis tasks. | No |
| `scripts/review_codebase.py` | Code review automation script. | No |
| `scripts/test_reality_check.py` | Tests reality-check hook behavior directly. | No |
| `scripts/update_capabilities.py` | Updates skill capabilities metadata from skill definitions. | No |
| `scripts/update_primary_gemini.py` | Updates primary Gemini model alias in config. | No |
| `scripts/validate_providers.py` | Validates provider config and API credentials against config.yaml. | No |
| `run_reality_check.py` | One-off script: runs `testing-reality-checker` skill via `router.execute()` against a local file. | Via router |
| `edit_commit_msg.py` | Git commit message editor hook. Not an LLM tool. | No |
| `edit_rebase_todo.py` | Git rebase todo editor hook. Not an LLM tool. | No |

### Tests

All test files in `tests/` verify behavior of the above components. They do not produce LLM output directly; they mock or invoke the production pipeline under test conditions.

| File | Covers |
|------|--------|
| `tests/test_hooks.py` | Hook execution, always-on enforcement, result merging |
| `tests/test_runtime_app.py` | `/execute` endpoint, crash mode, cognitive state |
| `tests/test_cognitive_runtime.py` | State parsing, mode inference, energy-adaptive filtering |
| `tests/test_webhooks.py` | Webhook receiver, deduplication, handler dispatch |
| `tests/test_cognitive.py` | Cognitive state transitions, energy levels |
| `tests/test_router.py` | `SkillRouter`: skill loading, model chain failover |
| `tests/test_validation.py` | Output validation constraints |
| `tests/test_sanitize.py` | Input sanitization patterns |
| `tests/test_schemas.py` | Schema parsing and validation |
| `tests/test_auth.py` | Authentication and HMAC verification |
| `tests/test_planner.py` | Capability chain planning |
