# SK-SCHOLAR: AuDHD Knowledge Injection (P2.7)

## Purpose
Always-on pre_execute hook that injects PROFILE.md cognitive model context into every skill's prompt. Single source of AuDHD cognitive fluency for the swarm.

## Cognitive Rationale
Every skill in the swarm needs AuDHD-aware framing. Without SK-SCHOLAR, each skill carries partial or no understanding of the cognitive architecture. SK-SCHOLAR ensures consistent cognitive grounding across all skill executions.

## What This Hook Actually Does
[GROUNDED] Prompt-injection. Zero inference cost.

1. **Mode-specific pattern injection**: Selects the relevant PROFILE.md cognitive pattern for the active mode (execute→pattern compression, design→asymmetric working memory, review→meta-layer reflex, etc.)
2. **Energy-appropriate framing**: Injects capacity constraints (high=full, medium=standard, low=core only, crash=single action)
3. **Monotropism contract**: Injects switch cost and thread enforcement based on `context_switches` count
4. **Context monitoring integration**: If P2.5 signals are present in options (energy signals, drift, overload), includes them in the cognitive lens
5. **Design constraint enforcement**: Every injection includes "augmentation for competent adult, not caretaker"

## What This Hook Does NOT Do
[NOT FEASIBLE with current architecture]

- Does not intercept skill-to-skill communication (no inter-skill bus exists)
- Does not override orchestrator routing decisions (orchestrator owns routing)
- Does not maintain persistent state across requests (hooks are request-scoped)
- Does not act as a supervisor (that role belongs to the orchestrator via cognitive.py)
- Does not perform ML inference (zero-cost prompt injection only)

## Hook Lifecycle
- **Phase**: `prompt_injection` (runs as part of hook chain)
- **Priority**: 5 (runs early, before mode-specific hooks)
- **Always-on**: Yes (in ALWAYS_ON_HOOKS alongside SK-REALITY, SK-ENERGY)
- **Energy gated**: Partially (crash mode gets minimal injection to reduce overhead)
- **Model routing**: None (zero inference cost)

## Mode-Pattern Mapping

| Mode | Injected Pattern |
|------|------------------|
| execute | Pattern compression. Verdict first. Produce immediately. |
| design | Asymmetric working memory. Full system map first. |
| review | Meta-layer reflex. Audit system, not just outcome. |
| troubleshoot | Monotropic lock. One hypothesis, one test, one result. |
| osint | Parallel subagent decomposition. Recurse 3 degrees. |
| decide | Externalize tradeoffs as table. Optimize reversibility. |
| draft | Audience-matched output. Produce artifact directly. |
| rewrite | Source-matched register. Preserve author voice. |
| summarize | Maximum compression. Verdict density. |
| chat | Conversational. Follow operator's branch. No tangents. |

## Output Metadata
```json
{
  "scholar_mode_pattern": "execute",
  "scholar_energy_frame": "medium",
  "scholar_switches": 0
}
```

## Integration
```python
# In runtime/hooks.py:
from runtime.hooks_scholar import patch_hook_registry
patch_hook_registry(HOOK_REGISTRY, ALWAYS_ON_HOOKS)
```

## Grounding Status: ✅ GROUNDED
Implemented in `runtime/hooks_scholar.py`. All capabilities are prompt-injection only. No aspirational features.
