# SK-STT: Speech-to-Text Preprocessing (v2)

## Purpose
Pre-execute hook that normalizes raw speech transcription for AuDHD cognitive patterns before routing to mode inference and skill execution.

## Cognitive Rationale
AuDHD speech patterns include mid-sentence topic shifts, false starts, verbal stim/filler, restart loops, compressed multi-topic bursts, and stutter repetitions. Raw STT transcripts lose intent when these aren't cleaned. SK-STT bridges the gap between how the user *speaks* and what the system needs to *process*.

## Hook Lifecycle
- **Phase**: `pre_execute`
- **Priority**: 0 (runs first)
- **Runs before**: Mode inference (`infer_mode`), SK-ANCHOR, all other hooks
- **Input**: Raw transcript string from STT engine + cognitive state
- **Output**: Cleaned `input_text` + `stt_metrics` + `stt_confidence` + deferred topics

## Processing Pipeline (8 stages)

### Stage 1: Misrecognition Correction
Apply context-aware correction table for common STT errors:
- **Technical homophones**: "cash" -> "cache", "sequel" -> "SQL", "jason" -> "JSON", "pie thon" -> "Python", "get hub" -> "GitHub", "doctor" -> "Docker"
- **Acronym expansion**: "h t t p" -> "HTTP", "ess ess h" -> "SSH", "you are l" -> "URL"
- **AuDHD terminology**: "mono tropism" -> "monotropism", "hyper focus" -> "hyperfocus"
- **Swarm model names**: "g pro 31" -> "G-PRO", "o 4 mini" -> "O-O4M"

Correction table is extensible via `stt_custom_corrections` option.

### Stage 2: Repeated Phrase Deduplication
Detect and collapse stutter/restart repetitions:
- "the thing is the thing is" -> "the thing is"
- "I want to I want to fix" -> "I want to fix"
- Scans for 2-6 word phrase repetitions within adjacent windows
- Flags `STT-STUTTER` when detected

### Stage 3: False Start Removal
Detect and remove restart patterns:
- "I need to... wait, actually I want to..." -> extract final intent
- "let me restart", "let me rephrase", "sorry, let me think"
- Supports: wait, no, actually, sorry, let me restart/start over/rephrase/think
- Flags `STT-RESTART`, counts false starts in metrics

### Stage 4: Context-Aware Filler Filtering
**Unconditional removal**: um, uh, erm, hmm, basically, honestly, literally

**Conditional removal** (preserved when semantic):
- "like": KEPT in comparisons ("looks like", "something like") and similes ("like a", "like the")
- "right": KEPT in confirmations ("that's right") and spatial ("right here", "right now")
- "so": KEPT mid-sentence (only stripped sentence-initial)
- "i mean": KEPT when followed by content (correction pattern)
- "actually": KEPT mid-sentence (only stripped sentence-initial without context)

Flags `STT-FILLER-HEAVY` when >30% of words are fillers.

### Stage 5: Sentence Boundary Repair
STT engines often drop punctuation, producing run-on sentences. Heuristic insertion:
- Before new-sentence signals: "I need", "I want", "I think", "I should"
- Before question patterns: "can you", "could you", "would you", "should you"

### Stage 6: Topic Shift Detection
Identify and extract topic diversions. Supports nested shifts.
- **Signals** (most specific first): "oh one more thing", "before i forget", "switching gears", "different topic", "unrelated but", "on a tangent", "quick sidebar", "oh and also", "come to think of it", "while i'm at it", "oh wait", "sidebar", "tangent"
- Extracted topics queued in `deferred_topics` for SK-ANCHOR
- Nested shifts within deferred topics also extracted
- Flags `STT-TOPIC-SHIFT`

### Stage 7: Compressed Burst Splitting
AuDHD users often compress multiple requests into one breath:
- Splits on: "and (then/also)", "also", "then", "plus", "oh and"
- Strips request prefixes: "can you", "please", "could you"

**Energy-adaptive handling:**
| Energy | Behavior |
|---|---|
| high | Keep all intents as single input |
| medium | Take first 2 intents, defer rest |
| low | Take first intent only, defer all others |
| crash | Pass through unchanged |

Flags `STT-MULTI-INTENT` with `intent_count` in metrics.

### Stage 8: Confidence Scoring
Compute processing confidence based on cleanup intensity:
- Base: `1.0 - (cleanup_ratio * 1.5)` where cleanup_ratio = words_removed / original_words
- Penalty: 0.8x multiplier when 3+ flags present
- Floor: 0.1 minimum
- Flags `STT-LOW-CONFIDENCE` when < 0.5

## Metrics Output
```json
{
  "stt_metrics": {
    "original_length": 245,
    "original_words": 42,
    "final_words": 28,
    "corrections": 3,
    "dedup_count": 1,
    "false_starts": 2,
    "fillers_removed": 5,
    "topic_shifts": 1,
    "intent_count": 2,
    "cleanup_ratio": 0.333,
    "confidence": 0.72
  },
  "stt_confidence": 0.72,
  "stt_original": "(raw transcript preserved for audit)",
  "stt_flags": ["STT-RESTART", "STT-MULTI-INTENT"],
  "deferred_topics": ["check the readme too"]
}
```

## Model Routing
[OBS — G-FLA31 is not a registered alias in adapters/config.yaml. Using registered aliases only.]
- **Primary**: O-O4M (o4-mini — registered T1 rapid verifier, lowest cost)
- **Fallback**: O-53 (gpt-5.3 — registered T2 overflow)
- **Never**: T4+ models (C-OP46, O-54P) for preprocessing
- **Note**: Register G-FLA alias → gemini-2.5-flash-lite in config.yaml if Gemini preprocessing is preferred
- STT inference itself is external (Whisper, Google Cloud Speech, Deepgram, Azure)

## SK-ANCHOR Integration
`deferred_topics` from stages 6-7 are passed to SK-ANCHOR's deferred queue, ensuring topic diversions are parked and retrievable without cognitive overhead.

## Claim Tags
- [GEN] AuDHD speech patterns include false starts and topic shifts
- [DRV] Preprocessing before mode inference improves downstream routing accuracy
- [SPEC] Specific filler word list and correction table may need tuning per user
- [DRV] Confidence scoring approximates signal-to-noise ratio of input
