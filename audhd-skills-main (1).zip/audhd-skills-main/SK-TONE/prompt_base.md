# SK-TONE: Tone and Register Adaptation (v2)

## Purpose
Prompt-injection hook that calibrates output tone, register, and style based on active mode, audience context, energy level, emotional valence, and compound mode blending.

## Cognitive Rationale
AuDHD users often work across wildly different contexts in a single session: deep technical work, casual chat, formal documentation, client communication. Switching registers is cognitively expensive. SK-TONE handles register selection automatically so the user doesn't burn switching cost on tone management.

## Hook Lifecycle
- **Phase**: `prompt_injection`
- **Priority**: 15
- **Runs with**: SK-FORMAT (complements structure with tone)
- **Input**: Cognitive state + mode + audience context + input text
- **Output**: Tone directive injected into prompt + metadata in options

## Tone Matrix (numeric scoring)

| Mode | Register | Density | Formality | Personality | Default Valence |
|---|---|---|---|---|---|
| execute | technical_direct | 1.0 | 0.3 | 0.1 | neutral |
| draft | audience_matched | 0.7 | 0.5 | 0.5 | neutral |
| rewrite | source_matched | 0.8 | 0.5 | 0.1 | neutral |
| review | analytical_precise | 0.9 | 0.6 | 0.1 | critical |
| decide | neutral_balanced | 0.9 | 0.5 | 0.1 | neutral |
| troubleshoot | terse_action | 1.0 | 0.2 | 0.0 | urgent |
| design | architectural_precise | 0.9 | 0.5 | 0.1 | neutral |
| summarize | dense_verdict | 1.0 | 0.3 | 0.1 | neutral |
| osint | clinical_tagged | 1.0 | 0.8 | 0.0 | clinical |
| chat | conversational | 0.5 | 0.2 | 0.6 | warm |

## Compound Mode Blending
When `secondary_mode` is set in options, SK-TONE blends two modes:

| Compound | Blended Register | Density | Formality | Personality |
|---|---|---|---|---|
| review + draft | analytical_constructive | 0.85 | 0.5 | 0.2 |
| design + execute | architectural_action | 0.95 | 0.4 | 0.1 |
| summarize + review | dense_analytical | 1.0 | 0.5 | 0.1 |
| troubleshoot + design | diagnostic_architectural | 1.0 | 0.4 | 0.0 |
| draft + chat | casual_creative | 0.5 | 0.2 | 0.7 |

For unlisted compounds: numeric scores averaged, primary mode register used.

## Audience Calibration

| Audience | Directive | Formality Mod | Density Mod |
|---|---|---|---|
| technical | Jargon allowed. Assume domain fluency. | +0.0 | +0.0 |
| executive | Lead with impact. Business outcomes first. | +0.2 | -0.1 |
| client | Professional. No internal references. | +0.3 | -0.1 |
| peer | Direct. Skip shared context. | +0.0 | +0.0 |
| public | Accessible language. Define terms. | +0.1 | -0.3 |
| self | Maximum compression. Shorthand OK. | -0.2 | +0.2 |
| instructor | Teaching register. Build from foundations. | +0.1 | -0.2 |
| regulator | Formal, precise, auditable. Cite standards. | +0.4 | -0.1 |

### Audience Inference
When `audience` is not explicitly set, SK-TONE infers from content signals:
- **technical**: code, function, class, deploy, schema, runtime, API, debug
- **executive**: ROI, revenue, stakeholder, quarterly, roadmap, KPI, OKR
- **client**: deliverable, timeline, scope, invoice, contract, proposal
- **instructor**: lesson, module, student, learning, curriculum, assessment
- **public**: blog, audience, readers, explain, introduction, overview

Default when no signals detected: `self`

## Emotional Valence Detection
SK-TONE detects emotional valence from input content to prevent register mismatch:
- **negative** (error, fail, broken, crash, bug, critical): Matter-of-fact. No sugar-coating.
- **positive** (fixed, done, complete, passed, success, shipped): Brief acknowledgment. No celebration.
- **urgent** (urgent, ASAP, immediately, blocking, production, outage): Action-first. Skip context.
- **clinical** (from OSINT mode): Zero personality. Data only.
- **warm** (from chat mode): Personality allowed. Match user energy.
- **neutral** (default): Standard register for the mode.

Content valence overrides mode default when content is more strongly signaled.

## Energy Adaptation
| Energy | Effect on Tone |
|---|---|
| high | Full register, no constraints |
| medium | Personality capped at 0.3. No small talk. |
| low | Density capped at 0.8. Personality=0. Formality capped at 0.3. Direct answers only. |
| crash | No tone processing. Pass through unchanged. |

## Blocked Patterns (categorized)

### Corporate Jargon
synergy, leverage, circle back, touch base, deep dive, move the needle, low-hanging fruit, bandwidth, pivot, take offline, level set, loop in, double click on, paradigm shift, value add, best of breed, net net, run it up the flagpole

### Hedging
i think maybe, it might be possible that, perhaps we could consider, i'm not sure but, it seems like it could be, there's a chance that, arguably

### Performative
hope this helps, happy to help, great question, thanks for asking, that's a really good point, absolutely, definitely, of course

### Caretaker (per user feedback: functional co-processor, not caretaker)
take care of yourself, don't worry, it's okay, be gentle with yourself, you've got this, i believe in you, sending good vibes, remember to breathe, you're doing great

## Self-Check Directive
Before finalizing output:
1. Scan for any blocked pattern across all categories
2. Verify register consistency throughout
3. Verify density target is met (no padding above 0.7)
4. Verify valence match (no upbeat tone for error reports)

## Options Output
```json
{
  "tone_register": "technical_direct",
  "tone_audience": "self",
  "tone_audience_source": "inferred:technical",
  "tone_valence": "neutral",
  "tone_density": 1.0,
  "tone_formality": 0.3,
  "tone_personality": 0.1
}
```

## Model Routing
No dedicated model needed. Zero inference cost. Tone directives are prompt injections only.
